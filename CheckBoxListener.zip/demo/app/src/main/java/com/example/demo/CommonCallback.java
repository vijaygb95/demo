package com.example.demo;

public interface CommonCallback {
    public  void mainCheckBoxStauts(boolean status);
}
