package com.example.demo;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ExpandableListAdapterMap extends BaseExpandableListAdapter {

    private Map<Integer,UserModel> mDataList;
    private Context context;
    private LayoutInflater inflater;
    CommonCallback commonCallback;

    //Constructors
    public ExpandableListAdapterMap() {

    }

    public ExpandableListAdapterMap(Context context, Map<Integer,UserModel> mDataList, CommonCallback commonCallback) {
        this.context = context;
        this.mDataList = mDataList;
        this.commonCallback=commonCallback;
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    //Get Methods
    public Object getChild(int groupPosition, int childPosition) {
        return mDataList.get(groupPosition).getChildData().get(childPosition);
    }

    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    public int getChildrenCount(int groupPosition) {
        return mDataList.get(groupPosition).getChildData().size();
    }

    public View getChildView(final int groupPosition, final int childPosition, boolean isLastChild,
                             View convertView, ViewGroup parent) {

        final ViewHolderChild viewHolderChild;

        if (convertView == null) {
            convertView = inflater.inflate(R.layout.layout_child, null);
            viewHolderChild = new ViewHolderChild();

            viewHolderChild.cbChild = convertView.findViewById(R.id.childCheck);
            convertView.setTag(viewHolderChild);
        } else {
            viewHolderChild = (ViewHolderChild) convertView.getTag();
        }

        if (mDataList.get(groupPosition).getChildData().get(childPosition).getChildStatus()) {
            viewHolderChild.cbChild.setChecked(true);
//            notifyDataSetChanged();
        } else {
            viewHolderChild.cbChild.setChecked(false);
//            notifyDataSetChanged();
        }
        viewHolderChild.cbChild.setText(mDataList.get(groupPosition).getChildData().get(childPosition).getChildTitle());
        viewHolderChild.cbChild.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (viewHolderChild.cbChild.isChecked()) {
                    mDataList.get(groupPosition).getChildData().get(childPosition).setChildStatus(true);
//                    notifyDataSetChanged();
                } else {
                    mDataList.get(groupPosition).getChildData().get(childPosition).setChildStatus(false);
//                    notifyDataSetChanged();
                }

                boolean childStatus = false;
                for (int i = 0; i < mDataList.get(groupPosition).getChildData().size(); i++) {
                    if (mDataList.get(groupPosition).getChildData().get(i).getChildStatus()) {
                        childStatus = true;
                    } else {
                        childStatus = false;
                        break;
                    }
                }
                if (childStatus) {
                    mDataList.get(groupPosition).setGroupStatus(true);
                    notifyDataSetChanged();
                } else {
                    mDataList.get(groupPosition).setGroupStatus(false);
                    notifyDataSetChanged();
                }

                boolean groupStatus = false;
                for (int i = 0; i < mDataList.size(); i++) {
                    if (mDataList.get(i).getGroupStatus()) {
                        groupStatus = true;
                    } else {
                        groupStatus = false;
                        break;
                    }
                }
                commonCallback.mainCheckBoxStauts(groupStatus);

            }
        });
        return convertView;
    }

    public Object getGroup(int groupPosition) {
        return mDataList.get(groupPosition);
    }

    public int getGroupCount() {
        return mDataList.size();
    }

    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    public View getGroupView(final int groupPosition, boolean isExpanded, View convertView,
                             ViewGroup parent) {
        final ViewHolderParent viewHolderParent;

        if (convertView == null) {
            convertView = inflater.inflate(R.layout.layout_group, null);
            viewHolderParent = new ViewHolderParent();
            viewHolderParent.cbGroup = convertView.findViewById(R.id.groupCheck);
            convertView.setTag(viewHolderParent);
        } else {
            viewHolderParent = (ViewHolderParent) convertView.getTag();
        }

        if (mDataList.get(groupPosition).getGroupStatus()) {
            viewHolderParent.cbGroup.setChecked(true);
//            notifyDataSetChanged();
        } else {
            viewHolderParent.cbGroup.setChecked(false);
//            notifyDataSetChanged();
        }
        viewHolderParent.cbGroup.setText(mDataList.get(groupPosition).getGroupTitle());
        viewHolderParent.cbGroup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (viewHolderParent.cbGroup.isChecked()) {
                    mDataList.get(groupPosition).setGroupStatus(true);
//                    notifyDataSetChanged();
                } else {
                    mDataList.get(groupPosition).setGroupStatus(false);
//                    notifyDataSetChanged();
                }
                if (mDataList.get(groupPosition).getGroupStatus()) {
                    for (int i = 0; i < mDataList.get(groupPosition).getChildData().size(); i++) {
                        mDataList.get(groupPosition).getChildData().get(i).setChildStatus(true);
                    }
                    notifyDataSetChanged();
                } else {
                    for (int i = 0; i < mDataList.get(groupPosition).getChildData().size(); i++) {
                        mDataList.get(groupPosition).getChildData().get(i).setChildStatus(false);
                    }
                    notifyDataSetChanged();
                }

                boolean groupStatus = false;
                for (int i = 0; i < mDataList.size(); i++) {
                    if (mDataList.get(i).getGroupStatus()) {
                        groupStatus = true;
                    } else {
                        groupStatus = false;
                        break;
                    }
                }
                commonCallback.mainCheckBoxStauts(groupStatus);

            }
        });

        return convertView;
    }


    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return false;
    }

    public boolean hasStableIds() {
        return true;
    }

    @Override
    public void onGroupCollapsed(int groupPosition) {
        super.onGroupCollapsed(groupPosition);
    }

    @Override
    public void onGroupExpanded(int groupPosition) {
        super.onGroupExpanded(groupPosition);
    }

    private class ViewHolderParent {
        CheckBox cbGroup;
    }

    private class ViewHolderChild {
        CheckBox cbChild;
    }
}
