package com.example.demo;

import java.util.ArrayList;

public class UserModel {
    private String groupTitle;
    private boolean groupStatus;
    private ArrayList<Child> childData;

    public UserModel(String groupTitle, boolean groupStatus, ArrayList<UserModel.Child> childData) {
        this.groupTitle = groupTitle;
        this.groupStatus = groupStatus;
        this.childData = childData;
    }

    public String getGroupTitle() {
        return groupTitle;
    }

    public void setGroupTitle(String groupTitle) {
        this.groupTitle = groupTitle;
    }

    public boolean getGroupStatus() {
        return groupStatus;
    }

    public void setGroupStatus(boolean groupStatus) {
        this.groupStatus = groupStatus;
    }

    public ArrayList<Child> getChildData() {
        return childData;
    }

    public void setChildData(ArrayList<Child> childData) {
        this.childData = childData;
    }

    public static class Child {
        private String childTitle;
        private boolean childStatus;

        public Child(String childTitle, boolean childStatus) {
            this.childTitle = childTitle;
            this.childStatus = childStatus;
        }

        public String getChildTitle() {
            return childTitle;
        }

        public void setChildTitle(String childTitle) {
            this.childTitle = childTitle;
        }

        public boolean getChildStatus() {
            return childStatus;
        }

        public void setChildStatus(boolean childStatus) {
            this.childStatus = childStatus;
        }
    }
}
