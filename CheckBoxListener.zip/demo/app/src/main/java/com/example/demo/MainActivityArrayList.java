package com.example.demo;

import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.example.demo.databinding.ActivityMainBinding;

import java.util.ArrayList;

public class MainActivityArrayList extends AppCompatActivity {
    ActivityMainBinding activityMainBinding;
    ExpandableListAdapterArrayList expandableListAdapter;
    ArrayList<UserModel> userDataList = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activityMainBinding = DataBindingUtil.setContentView(this, R.layout.activity_main);
        prepareData(false);
        setAdapter();
        activityMainBinding.cbMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (activityMainBinding.cbMain.isChecked()) {
                    prepareData(true);
                } else {
                    prepareData(false);
                }
                expandableListAdapter.notifyDataSetChanged();
            }
        });
    }

    private void prepareData(boolean cbMainStatus) {
        userDataList.clear();
        for (int i = 0; i < 3; i++) {
            ArrayList<UserModel.Child> childData = new ArrayList<>();
            for (int j = 0; j < 4; j++) {

                childData.add(new UserModel.Child("Child" + i + " of " + j, cbMainStatus));
            }
            userDataList.add(new UserModel("Title" + i, cbMainStatus, childData));
        }
    }

    private void setAdapter() {
        expandableListAdapter = new ExpandableListAdapterArrayList(this, userDataList, commonCallback);
        activityMainBinding.expandable.setAdapter(expandableListAdapter);
    }

    CommonCallback commonCallback = new CommonCallback() {
        @Override
        public void mainCheckBoxStauts(boolean status) {
            activityMainBinding.cbMain.setChecked(status);
        }
    };
}
